#!/bin/bash

echo "========== Step4: Uninstall docker and containerd if Exist🔗 =========="
sudo apt-get remove docker docker-engine docker.io containerd runc -y
sleep 5
echo -e "\n\n"

echo -e "========== Step5: Installing Containerd ==========\n"

# Configure persistent loading of modules
sudo tee /etc/modules-load.d/containerd.conf <<EOF
overlay
br_netfilter
EOF

# Load at runtime
sudo modprobe overlay
sudo modprobe br_netfilter

# Ensure sysctl params are set
sudo tee /etc/sysctl.d/kubernetes.conf<<EOF
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
EOF

# Reload configs
sudo sysctl --system

# Install required packages
sudo apt install -y curl gnupg2 software-properties-common apt-transport-https ca-certificates

# Add Docker repo
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

# Install containerd
sudo apt update
sudo apt install -y containerd.io

# restart containerd
sudo systemctl restart containerd
sudo systemctl enable containerd
sudo systemctl enable kubelet

rm -rf /etc/containerd/config.toml
sudo systemctl restart containerd
sudo systemctl restart kubelet

